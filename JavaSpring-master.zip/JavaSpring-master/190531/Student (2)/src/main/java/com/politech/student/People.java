package com.politech.student;

public class People {
	public int idx;
	public String name;
	public String favoriteColor;
	
	People() {
	}
	People(String name, String favoriteColor) {
		this.name = name;
		this.favoriteColor = favoriteColor;
	}
}
