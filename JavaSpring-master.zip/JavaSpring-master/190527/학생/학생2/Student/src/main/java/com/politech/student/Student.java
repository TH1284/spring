package com.politech.student;

public class Student {
	String name;
	String address;
	String birthday;
	
	Student(String name, String address, String birthday) {
		this.name = name;
		this.address = address;
		this.birthday = birthday;
	}
}
